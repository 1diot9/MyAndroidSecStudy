@echo off

"%~dp0python.exe" "%~dp0bin\drozer" %*
