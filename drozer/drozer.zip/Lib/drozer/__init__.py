import mwr.common.stream as stream

# Every drozer command imports this package. Install the codec hooks once,
# before modules format device strings or print them.
stream.install_console_encoding()
