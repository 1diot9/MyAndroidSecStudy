import unicodedata

def _as_text(value):
    """
    Coerce a table cell to unicode.

    Device strings are UTF-8. Decoding them here keeps column widths in
    characters, instead of UTF-8 bytes, before the console encodes the line.
    """

    if value is None:
        return u""
    if isinstance(value, unicode):
        return value
    if isinstance(value, str):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("mbcs", "replace")

    try:
        return unicode(value)
    except UnicodeError:
        return str(value).decode("utf-8", "replace")

def _display_width(text):
    """
    Console columns used by text. Fullwidth characters (most Chinese) take two.
    """

    width = 0
    for char in text:
        if unicodedata.east_asian_width(char) in ("W", "F"):
            width += 2
        else:
            width += 1

    return width

def _pad(text, width):
    gap = width - _display_width(text)
    if gap > 0:
        return text + (u" " * gap)

    return text

class TableFormatter(object):
    """
    Utility methods for formatting tabular data.
    """

    def print_table(self, rows, show_headers=True, vertical=False):
        """
        Print tabular data to stdout, given an array of rows, each containing
        an array of values.

        It is assumed that the first row contains column headers.
        """

        if vertical:
            self.print_table_vertical(rows)
        else:
            self.print_table_horizontal(rows, show_headers)

    def print_table_horizontal(self, rows, show_headers=True):
        """
        Print tabular data in a traditional, horizontal format:

        | a | b | c |
        | 1 | 2 | 3 |
        """

        text_rows = [[_as_text(cell) for cell in row] for row in rows]
        widths = []

        for i in xrange(len(text_rows[0])):
            widths.append(max(_display_width(row[i]) for row in text_rows))

        if show_headers:
            self.stdout.write(_format_row(text_rows[0], widths) + u"\n")

        for row in text_rows[1:]:
            self.stdout.write(_format_row(row, widths) + u"\n")
        self.stdout.write(u"\n")

    def print_table_vertical(self, rows):
        """
        Print tabular data in a vertical format, which is easier to read with
        long fields names or values:

        a: 1
        b: 2
        c: 3
        """

        text_rows = [[_as_text(cell) for cell in row] for row in rows]
        headers = text_rows.pop(0)

        width = max(_display_width(header) for header in headers)

        for row in text_rows:
            for i in xrange(len(headers)):
                self.stdout.write(_pad_left(headers[i], width) + u"  " + row[i] + u"\n")
            self.stdout.write(u"\n")
        self.stdout.write(u"\n")

def _format_row(row, widths):
    parts = [u"|"]

    for i in xrange(len(row)):
        parts.append(u" ")
        parts.append(_pad(row[i], widths[i]))
        parts.append(u" |")

    return u"".join(parts)

def _pad_left(text, width):
    gap = width - _display_width(text)
    if gap > 0:
        return (u" " * gap) + text

    return text
